# Design Example Title

## Introduction

Describe your design example. 

Example: 

The Nios® V processor starts executing the boot copier upon system reset, which copies the application from the configuration quad serial peripheral interface (QSPI) to the internal RAM. Once this completes, the Nios V/g processor transfers the program control over to the application.

## Block Diagram

Include your block diagrams.

Example:

![image](https://github.com/Intel-Design-Store/template/assets/91928627/beb1191e-3077-4a62-905b-45833c3c7b12)


**You are welcome to include any information you believe is relevant or valuable.**
